<?php
/*
Descripcion:
Crea un formulario web a partir de una consulta proporcionada
   $formulario = new formulario ($sql,$camposocultos,$camposbloqueados, $val, $campollave,$tablasrelaciones)
----------------------------------------------------------------------------------------------------------------------
bandera    | Nombre               |   Tipo     |   Descripcion                                                       |
----------------------------------------------------------------------------------------------------------------------
requerido  | $sql                 |   string   |   Consulta que se usa para crear el formulario                      |
----------------------------------------------------------------------------------------------------------------------
opcional   | $camposocultos       |   array    |   Array de campos que no deben mostrarse en la consulta             |
----------------------------------------------------------------------------------------------------------------------
opcional   | $camposbloqueados    |   array    |   Array de campos que permanecen de sololectura en el formulario    |
           |                      |            |   creado                                                            |
----------------------------------------------------------------------------------------------------------------------
opcional   | $val                 |   array    |   Array asociativo de campos => valor , de los campos que tendran   |
           |                      |            |   un valor                                                          |
           |                      |            |   predefinido en los formularios                                    |
----------------------------------------------------------------------------------------------------------------------
opcional   | $tablasrelaciones    |   array    |   Array de tablas con las que tiene relacion la tabla para          |  
           |                      |            |   creacion del form.                                                |
----------------------------------------------------------------------------------------------------------------------
*/

require ("mysql.inc.php");
require ("encryptFunction.php");

class formulario
{
    var $contrato;
    var $acampos;//Campos que no deben mostrarse
    var $bcampos;//Campos que se bloquean en eel formulario
    var $val;//valores por default al insertar
    var $sql;//consulta sql general
    var $read;//indica si la etiqueta input es de solo lectura
    var $campollave;//Arrat de campo llave de de la tabla en cuestion
    var $mysql_err; //captura el error generado por el servidor mysql
    var $transaccion ; //indica si se esta realizando una tansaccion
    //array asosiativo que contendra las opciones para los valores de los select
    var $onfocus="#FFCC99"; //color d texto al recibir el foto
    var $tablasrelaciones; //array proporcionado que contendra las demas tablas relacionadas (opcional)
    var $select;
    //ruta de las imagenes eliminar, modificar, etc
    var $PathImages = "http://127.0.0.1/Joomla/intelcode/Modulos/imagenes/";

    //constructutor
    function formulario($sql, $camposNo = "",$camposBlo="", $val = "", $campollave = "",$tablasrelaciones)
    {
         global $sContrato;
        $this->contrato =  $sContrato;
        $this->sql = $sql;
        $this->acampos = $camposNo;
        $this->val = $val;
        $this->campollave = $campollave;
        $this->mysql_err = false ;
        $this->tablasrelaciones = $tablasrelaciones;
        $this->bcampos = $camposBlo;
        $this->ponerselect();
    }
    //variables select
    function ponerselect(){
       $this->select = array(
	 	  "sIdTipoEmbarcacion" =>"select sIdTipoEmbarcacion,sDescripcion from tiposdeembarcacion",
        "sIdEmbarcacion" => "select sIdEmbarcacion,sDescripcion from embarcaciones",
        "sIdTipoConvenio" => "SELECT sIdTipoConvenio,sDescripcion FROM tiposdeconvenio",
        "sNumeroOrden" =>"SELECT sNumeroOrden FROM ordenesdetrabajo WHERE sContrato='$this->contrato' ORDER BY sNumeroOrden",
        "sContrato" =>"SELECT sContrato,Contrato  FROM contratos ORDER BY sContrato",
        "sIdUsuario" =>"SELECT sIdUsuario,sNombre  FROM usuarios ORDER BY sNombre",
        "sIdDepartamento" =>"SELECT sIdDepartamento,sDescripcion  FROM departamentos ORDER BY sDescripcion",
        "sIdPrograma" =>"SELECT sIdPrograma,sDescripcion  FROM programas ORDER BY sDescripcion");
   }
    //envia una alerta al usuario
    function alerta($alerta = "")
    {
        if ($alerta == "")
            $alerta = "Mensaje de Alerta!";
        echo "\n<script language='javascript'>\nalert(\" $alerta \" );\n</script>";
    }
    //verifica si un campo es llave en las tablas
    function llave($banderas)
    {
        if (strpos($banderas, "_key"))
            return true;
        else
            return false;
    }
    //verifica si el campo debe ser creado como select
    function tipoEnum($comentario)
    {
        if (strpos($comentario, "*"))
            return true;
        else
            return false;
    }
    //optiene el comentario de la tabla
    function comentarioTabla($Tabla)
    {
        if ( $Tabla =="" ) return ;
        $sql = "show table status like '$Tabla%'";
        $result = $this->query($sql);
        if ($row = mysql_fetch_array($result))
        {
            $Comentario = "";
            for ($i = 0; $i < strlen($row['Comment']); $i++)
            {
                if ($row['Comment'][$i] == ';')
                    return $Comentario;
                $Comentario .= $row['Comment'][$i];
            }
            return $row['Comment'];
        }
    }
    //optiene el comentario del campo
    function comentario($Campo, $Tabla)
    {
        if ( $Campo == "" or $Tabla == "" ) return 0;
        $sql = "show full columns from $Tabla like '%$Campo%'";
        $result = $this->query($sql);
        if ($row = mysql_fetch_array($result))
        {
			  return $row['Comment'];
        }
        else
            return "-";
    }
    //develve el nombre de la tabla
    function nombreTabla($result, $indice)
    {
        if (isset($result) and isset($indice))
        {
        		return mysql_field_table($result, $indice);
        }
        else
        		return ;
    }
    //devuelve las banderas del campo
    function banderas($result, $indice)
    {
        return mysql_field_flags($result, $indice);
    }
    //devuelve el tipo de campo
    function tipoCampo($result, $indice)
    {
        return mysql_field_type($result, $indice);
    }
    //devuelve el nombre del campo
    function nombreCampo($result, $indice)
    {
        return mysql_field_name($result, $indice);
    }
    //devuelve la longitud del campo
    function longCampo($result, $indice)
    {
        return mysql_field_len($result, $indice);
    }
    //devuelte true si el campo debe mostrarse en el grid
    function mostrarCampo($nombreCampo)
    {
        if ($this->acampos != "")
        {
            foreach ($this->acampos as $valor)
            {
                if ($nombreCampo == $valor)
                {
                    return false;
                    break;
                }
            }
        }
        return true;
    }
    //devuelte true si el campo debe bloquearse para editar
    function bloquearCampo($nombreCampo)
    {
        if ($this->bcampos != "")
        {
            foreach ($this->bcampos as $valor)
            {
                if ($nombreCampo == $valor)
                {
                    return false;
                    break;
                }
            }
        }
        return true;
    }
    //Ejecuta una consulta
    function query($sql)
    {
    	global $link;
       //$this->alerta($sql);
        if ($sql == "") return ;
        // echo "<br>".$sql;
		 //if ($this->mysql_err == 1 ) return ;
        $resultado = mysql_query($sql,$link);
        if (mysql_error())
        {
            $this->alerta("Error Num. ".mysql_errno()."  ".mysql_error());
            $this->mysql_err = 1 ;
            exit(0);
            //echo $sql;
        }
        return $resultado;
    }
    //Crea etiqueta input type = text tipo fecha
    function CreaTextoFecha($Nombre, $Tamanyo, $Comentario, $valor = "")
    {
        $valor = str_replace("\"", "", $valor);
        if ($Tamanyo < 1)
            $Tamanyo = 255;
        if ($Tamanyo > 100)
            $size = 100;
        else
            $size = $Tamayno;
        echo "\n<tr>
				\n<td>$Comentario</td>
				\n<td>
				\n<label for='$Nombre'>
				\n<input class='fecha rang100' id='$Nombre' type='text' size='$size' value='$valor'
               onKeyPress='return solonumeros(event);'   
               onfocus=\"style.backgroundColor='$this->onfocus'\"
               onblur=\"style.backgroundColor='white'\"
               maxlength='$Tamanyo' $this->read name='$Nombre'
               onkeyup='fn(this.form,this)'
                >
            \n</label>
				\n</td>
				\n</tr>";
			
		
    }
    //Crea etiqueta input type = text que solo acepta numeros
    function CreaTextoNumerico($Nombre, $Tamanyo, $Comentario, $valor = "")
    {
        $valor = str_replace("\"", "", $valor);
        if ($Tamanyo < 1)
            $Tamanyo = 255;
        if ($Tamanyo > 100)
            $size = 100;
        else
            $size = $Tamayno;
        echo "\n<tr>
				\n<td>$Comentario</td>
				\n<td>
				\n<input type='text' size='$size' value='$valor'
               onfocus=\"style.backgroundColor='$this->onfocus'\"
               onblur=\"style.backgroundColor='white'\"
               onkeyup='fn(this.form,this)'
               onKeyPress='return solonumeros(event);'   maxlength='$Tamanyo' $this->read name='$Nombre'
                >
				\n</td>
				\n</tr>";
    }
    //Crea etiqueta input type = text
    function CreaTexto($Nombre, $Tamanyo, $Comentario, $valor = "")
    {
        $valor = str_replace("\"", "", $valor);
        if ($Tamanyo < 1)
            $Tamanyo = 255;
        if ($Tamanyo > 100)
            $size = 100;
        else
            $size = $Tamayno;
        echo "\n<tr>
				\n<td>$Comentario</td>
				\n<td>
				\n<input type='text' size='$size' value='$valor'
               onfocus=\"style.backgroundColor='$this->onfocus'\"
               onblur=\"style.backgroundColor='white'\"
               onkeyup='fn(this.form,this)'
               onKeyPress='return NoComillas(event);' maxlength='$Tamanyo' $this->read name='$Nombre'
                >
				\n</td>
				\n</tr>";
    }
    //Crea etiqueta input type = select a partir de una consulta SELECT
    function CreaSelect($Nombre, $Sql, $Comentario, $valor = "")
    {
        $result = $this->query($Sql);
        echo "\n<tr>\n<td>\n$Comentario</td>\n<td>\n<select name='$Nombre' onkeyup='fn(this.form,this)'>";
        while ($row = mysql_fetch_row($result))
        {
            if ($row[0] == $valor)
                $seleccionar = "selected";
            else
                $seleccionar = "";
            echo "\n\t\t<option $seleccionar value='".$row[0]."'>".$row[1]."</option>";
        }
        echo "\n</select>\n</td></tr>";

    }
    //Crea etiqueta input type = select para selccionar colores
    function CreaSelectColor($Nombre, $Comentario,$valor)
    {
      $Opciones = array(	1 =>"Black","Maroon","Green","Olive","Navy","Purple","Teal","Gray","Silver",
							"Red","Lime","Yellow","Blue","Fuchsia","Aqua","White");
		print "\n<tr>\n<td>\n$Comentario</td><td>\n";					
      print "<select name='$Nombre' onkeyup='fn(this.form,this)'>";
      foreach($Opciones as $indice => $val) {
       	$Seleccionar= ($valor==$val or $valor==$indice) ? "Selected":"";
      	print "<option value='$indice' class='$val' $Seleccionar>$val</option>\n";
      } 
      print "</select>\n</td></tr>";
	}
    //Procesa Imagen
    function procesarImagen($contImaen,$nombre)
    {
      if (file_exists($nombre))
         unlink($nombre);
      $archivoImg = fopen($nombre,"w+");
      fwrite($archivoImg,$contImaen);
      return true;
    }

    //Crea etiqueta input = file para seleccionar imagenes
    function CreaImagen($Nombre, $Comentario)
    {
        echo " \n<tr><td>
				\n$Comentario
				\n</td><td>
				\n<input type='file' size='40' name='$Nombre'
               onfocus=\"style.backgroundColor='$this->onfocus'\"
               onblur=\"style.backgroundColor='white'\"  
               onkeyup='fn(this.form,this)'
               >
				\n</td></tr>";
    }
    //Crea etiqueta input = file para seleccionar imagenes
    function CreaImagenRuta($Nombre, $Comentario)
    {
        echo " \n<tr><td>
				\n$Comentario
				\n</td><td>
				\n<input type='file' size='40' name='$Nombre'
               onfocus=\"style.backgroundColor='$this->onfocus'\"
               onblur=\"style.backgroundColor='white'\" >
				\n</td></tr>";
    }
    //crea etiqueta input = select de campos enum con todos sus posibles valores
    function CampoEnum($tabla, $campo, $Comentario, $valor = "")
    {
        $sql = "DESCRIBE $tabla $campo";
        $result = $this->query($sql);
        echo "\n<tr><td>$Comentario</td>";
        while ($ligne = mysql_fetch_array($result))
        {
            extract($ligne, EXTR_PREFIX_ALL, "IN");
            if (substr($IN_Type, 0, 4) == 'enum')
            {
                $liste = substr($IN_Type, 5, strlen($IN_Type));
                $liste = substr($liste, 0, (strlen($liste) - 2));
                $enums = explode(',', $liste);
                if (sizeof($enums) > 0)
                {
                    echo "\n<td><select name='$campo' onkeyup='fn(this.form,this)'>";
                    for ($i = 0; $i < sizeof($enums); $i++)
                    {
                        $elem = trim(strtr($enums[$i], "'", " "));
                        if (trim($elem) == trim($valor))
                            $seleccionar = "selected";
                        else
                            $seleccionar = "";
                        echo "\n<option $seleccionar value='".$elem."'>".$elem."</option>";
                    }
                    echo "\n</select>";
                }
            }
        }
        echo "\n</td></tr>";
    }
    //crea etiqueta input = select de campos set con todos sus posibles valores
    function CampoSet($tabla, $campo, $Comentario="", $valor = "")
    {
        $sql = "DESCRIBE $tabla $campo";
        $result = $this->query($sql);
        echo "\n<tr><td>$Comentario</td>";
        
        while ($ligne = mysql_fetch_array($result))
        {
           extract($ligne, EXTR_PREFIX_ALL, "IN");
           if (substr($IN_Type, 0, 3) == 'set')
            {
                $liste = substr($IN_Type, 4, strlen($IN_Type));
                $liste = substr($liste, 0, (strlen($liste) - 2));
                $enums = explode(',', $liste);
                if (sizeof($enums) > 0)
                {
                    echo "\n<td><select name='$campo' onkeyup='fn(this.form,this)'>";
                    for ($i = 0; $i < sizeof($enums); $i++)
                    {
                        $elem = trim(strtr($enums[$i], "'", " "));
                        if (trim($elem) == trim($valor))
                            $seleccionar = "selected";
                        else
                            $seleccionar = "";
                        echo "\n<option $seleccionar value='".$elem."'>".$elem."</option>";
                    }
                    echo "\n</select>";
                }
            }
        }
        echo "\n</td></tr>";
    }
    //Inicia la transaccion
    function initransaccion(){
		$this->query("begin");
		$this->mysql_err = 0 ;
		$this->transaccion = 1 ;
	}
   //acepta la transaccion
    function aceptransaccion(){
		$this->query("commit");
		$this->transaccion = 0 ;
	}
   //destruye la transaccion
    function destransaccion(){
		$this->query("rollback");
		$this->transaccion = 0 ;
		$this->alerta("No se completo la operacion");
	}
   //	busca las tablas relacionadas con la actual
   function relaciones($tablaO)
   {
 	 	if ($tablaO == "") return;
        $arraytablas[] = "";
        $ocurrencias=$numtabla = 0;
        //recorrer todas las tablas
        $sql = " SHOW TABLES ";
        $listatablas = $this->query($sql);
        while ($filastablas = mysql_fetch_array($listatablas))
        {
            if ($filastablas[0] == $tablaO)
                continue;
            //recorrer los campos de cada tabla
            $sql = "SHOW FIELDS FROM ".$filastablas[0];
            $listacampos = $this->query($sql);
            while ($filascampos = mysql_fetch_array($listacampos))
            {
               	foreach($this->campollave as $campo)
	                if ($filascampos[0] == $campo){
					 	$ocurrencias++;
					}
            }
            //si la tabla contiene todos los campos llaves proporcionados
			if($ocurrencias == $numcampos = count($this->campollave)) {
				$arraytablas[++$numtabla] = $filastablas[0];
			}
			$ocurrencias = 0;

        }
        return $arraytablas;
    }
    //actualiza  todas las tablas que tienen el mismo campo
    function actRelaciones($tablas, $campos)
    {
        foreach ($tablas as $indice => $tabla)
        {
            if ($tabla != ""){
             	$sql = " UPDATE $tabla SET ";
    			foreach($campos as $nombre => $valor){
					$sql .= " $nombre = '$valor' ,";
				}   
				$sql = "$sql<";
				$sql = str_replace(",<","",$sql);
				$sql .= " WHERE  ";
				foreach($this->campollave as $campo){
					$sql .= "  $campo = '".$_SESSION[$campo]."' AND";
				} 
				$sql = "$sql<";
	            $sql = str_replace("AND<","",$sql);
	            $this->query($sql);
			}
        }
    }
    //busca antes de eliminar
    function busRelaciones($tablaO,$tablas, $campos)
    {
    	if($tabla !="none")
        foreach ($tablas as $indice => $tabla)
        {
         	if($tablaO == $tabla)continue;
            if ($tabla != "")
			{
			 	$sql="SELECT * FROM $tabla where";
			 	foreach($campos as $campo => $valor){
			 	 	if(!is_numeric($campo))
						$sql .= " $campo = '".trim($valor)."' AND";
				}
				$sql = "$sql<";	
				$sql = str_replace("AND<","",$sql);
				//$this->alerta($sql);
	   			$resultados = $this->query($sql);
	      		if($row = mysql_fetch_array($resultados)){
	                  $this->alerta("Existe relacion en ".$this->comentarioTabla($tabla));
	                  return true;
	            }
	         }
		}
 		 return false;	    
    }
    //Extrae el valor de (los) campo (s) llave(s) de partir de una cadena url proporcinada
    function extraervalor($url){
      //$this->alerta($url); 
      $url=explode("AND",$url);
      $arrayllaves[]="";
      foreach($url as $var){
         $var="-$var";
         foreach($this->campollave as $campo){
         	if($campo!="")
				$encontrado=strpos(trim($var),trim($campo));
			if($encontrado !== false){
 				$var = strstr($var,"=");
				$caracter = array("'","=");
				$arrayllaves[$campo]=str_replace($caracter,"",$var);
			//	$this->alerta($arrayllaves[$campo].$campo);
				
			}
		}
	  } 
     
	  return $arrayllaves;
    }
    //crea la consulta INSERT INTO a partir de la variable $_POST
    function crearInsert($_POST,$HTTP_POST_FILES)
    {
        $result = $this->query($this->sql);
        $tabla = $this->nombreTabla($result, 0);
        $numelementos = count($_POST);
        $contador = 0;
         //obtener imagen
         if(isset($HTTP_POST_FILES)){
             foreach($HTTP_POST_FILES  as $indice => $campImg)
             if($indice!="" and $HTTP_POST_FILES[$indice]['tmp_name'] !="")
                 $imagen = mysql_escape_string(join(@file($HTTP_POST_FILES[$indice]['tmp_name']))); 
                 $indiceImg= $indice;
         }    
        $sql = "INSERT INTO $tabla (\n";
        foreach ($_POST as $indice => $valor)
        {
            if ($valor == "Insertar" or $valor == "Modificar")
                continue;
            if ($contador++ == $numelementos - 2)
                $sql .= "\t$indice\n";
            else
                $sql .= "\t$indice,\n";
        }
         //Si selecciono una imagen agregarla al update
         if(isset($indiceImg) and isset($imagen)){
            $sql .= "\t, $indiceImg \n";
         }   
        $sql .= " ) VALUES (\n";
        $contador = 0;
        foreach ($_POST as $indice => $valor)
        {
            if ($valor == "Insertar" or $valor == "Modificar")
                continue;
            if ($contador++ == $numelementos - 2)
                $sql .= "\t'$valor'\n";
            else
                $sql .= "\t'$valor',\n";
        }
         //Si selecciono una imagen agregarla al update
         if(isset($indiceImg) and isset($imagen)){
            $sql .= "\t, '$imagen' \n";
         }   
        $sql .= ")";
        $this->query($sql);
    }
    //crea la consulta UPDATE a partir de la variable $_POST
    function crearUpdate($condicion, $_POST , $HTTP_POST_FILES )
    {

        $result = $this->query($this->sql);
        $tabla = $this->nombreTabla($result, 0);
        $numelementos = count($_POST);
        $contador = 0;
         //obtener imagen
         if(isset($HTTP_POST_FILES)){
             foreach($HTTP_POST_FILES  as $indice => $campImg)
                if($indice!="" and $HTTP_POST_FILES[$indice]['tmp_name'] !="")
                    $imagen = mysql_escape_string(join(@file($HTTP_POST_FILES[$indice]['tmp_name']))); 
                 $indiceImg= $indice;
         }    
        $sql = "UPDATE $tabla SET \n";
        foreach ($_POST as $indice => $valor)
        {
            foreach($this->campollave as $campollave)
            	if ($indice == $campollave)
	                $valorcampollave[$campollave] = $valor;
            if ($valor == "Insertar" or $valor == "Modificar")
                continue;
            if (++$contador == $numelementos - 1)
                $sql .= "\t$indice='$valor'\n";
            else
                $sql .= "\t$indice='$valor',\n";
        }
        //Si selecciono una imagen agregarla al update
         if(isset($indiceImg) and isset($imagen)){
            $sql .= "\t, $indiceImg='$imagen'\n";
         }   
        $sql .= "WHERE	$condicion";
        $this->initransaccion();
        if (isset($this->campollave) and $this->campollave != "" and $this->query($sql))
        {
            //si no se especifican las tablas relacionadas, buscarlas
            if (!$this->tablasrelaciones and $this->tablasrelaciones[0]!="none"){
            	$tablas = $this->relaciones($tabla);
            }
            else
               $tablas = $this->tablasrelaciones;
           if ($tablas and $this->tablasrelaciones[0]!="none")
                $this->actRelaciones($tablas, $valorcampollave);
        }
		if ( $this->mysql_err == 0 and $this->transaccion==1)
      		$this->aceptransaccion();
        else if ( $this->mysql_err==1 and $this->transaccion==1)
      		$this->destransaccion();
    }
    
    //crea la consulta DELETE a partir de la variable $_POST
    function crearDelete($condicion)
    {
        $result = $this->query($this->sql);
        $tabla = $this->nombreTabla($result, 0);
        $sql = "DELETE FROM  $tabla WHERE $condicion\n";
        $contenido = $this->extraervalor($condicion);
        //checar que no se este usando
        //si no se especifican las tablas relacionadas, buscarlas
        if (!$this->tablasrelaciones and $this->tablasrelaciones!="none")
            $tablas = $this->relaciones($tabla);
        else
            $tablas = $this->tablasrelaciones;
        //buscar concurrencias de registro en tablas relacionadas    
        $relacionado=false;
        if($this->tablasrelaciones[0]!="none")
           $relacionado = $this->busRelaciones($tabla,$tablas,$contenido);
        //si no hay , eliminar el registro
        if(!$relacionado)
        {   
            $this->initransaccion();
               $this->query($sql);
            if($this->mysql_err)
               $this->destransaccion();     
            else
               $this->aceptransaccion();      
        }
    }

    //verifica si alguna equiteta input debe tener valor predeterminado al insertar
    function valorCampo($nombreCampo)
    {
        if ($this->val != "")
        {
            foreach ($this->val as $indice => $valor)
            {
                if ($nombreCampo == $indice)
                {
                    return $valor;
                    break;
                }
            }
        }
    }
    //cambia caracteres
    function limpiar($cadena)
    {
        $cadena = str_replace("_", " ", $cadena);//alt + 15
        $cadena = str_replace("|", "=", $cadena);//alt + 10
        return $cadena = str_replace("*", "'", $cadena);//alt + 16
    }
    //cifrar el url
    function cifrar($array, $result)
    {
        $cadCifrar = "";
        $prefijo = "Sql=";
        foreach ($array as $indice => $valor)
        {
            if (is_numeric($indice))
            {
                $bandera = $this->banderas($result, $indice);
                $this->llave($bandera);
            }
            if ($this->llave($bandera) and !is_numeric($indice))
            {
                $cadCifrar .= "_$indice|*$valor*_AND";
            }
        }
         if($cadCifrar == ""){
           foreach ($array as $indice => $valor){
              foreach ($this->campollave as  $campo){
                  if ($campo==$indice and !is_numeric($indice)){
                      $cadCifrar .= "_$indice|*$valor*_AND";
                  }
              }
            }
         }
        $cadCifrar .= "<";
        $cadCifrar = str_replace("AND<", "", $cadCifrar);
        //cifrar el contenido
        $cadCifrar = encrypt($cadCifrar, 0);
        return $prefijo.$cadCifrar;
    }
    //crea un SELECT * FROM tabla, para crear el formulario
    function seleccionartodo($sql){
	    //  	echo "<br><br>Consulta :$sql<br><br>";
	      if(strpos($sql,"inner")!==false or strpos($sql,"INNER")!==false ){
	      	$result = $this->query($sql);
	      	$nuevosql = "SELECT * FROM ".$this->nombreTabla($result,0);
		}
		else{
		  $consulta = strstr($sql,"FROM");
		  $nuevosql = "SELECT * $consulta";
		}
		  return $nuevosql;
    }
    //Crea el formulario
    function CreaFormulario($Filtro = "")
    {

        if ($Filtro != "")
            $sql = $Filtro;
        else
            $sql = $this->sql;
        $sql = $this->seleccionartodo($sql);//seleccionar todos los campos
        $result = $this->query($sql);
        $row = mysql_fetch_array($result);
        $fields = mysql_num_fields($result);
        $table = $this->nombreTabla($result, 0);

        echo "\n<center>\n<form enctype='multipart/form-data' action='$_SERVER[PHP_SELF]'  method='POST'>";
        echo "\n<table>\n<caption>".$this->comentarioTabla($this->nombreTabla($result, 0))."</caption>";

        for ($i = 0; $i < $fields ; $i++)
        {
				//$this->alerta($this->nombreTabla($result, $i)!=$table);
            $tipo = $this->tipoCampo($result, $i);//Tipo de campo
            
            $nombre = $this->nombreCampo($result, $i);//Nombre de Campo
            $long = $this->longCampo($result, $i);//Longitud dle Campo
            $flags = $this->banderas($result, $i);//Banderas del Campo
            $comment = $this->comentario($nombre, $table);//Comentarios del Campo
            $esEnum = $this->tipoEnum($comment);//es campo select ?
            $comment = str_replace("/*", "", $comment);
            //si el comentario es nulo, porner como comentario el nombre de campo
            if($comment == "" )$comment = $nombre;
            
            //$this->read = $this->mostrarCampo($nombre) ? "":"readonly";
            $this->read = $this->bloquearCampo($nombre) ? "":"readonly";

            //poner valor por defecto en el formulario
            if ($Filtro == "" and  $this->val != "")// $Filtro == "" and 
            {
                $row[$i] = $this->valorCampo($nombre);
            }
           // $this->alerta("tipo: ".$tipo);
            //salvar valor del (los) campo (s) llave (s)
            foreach($this->campollave as $nom)
               if ($nom == $nombre)
                	$_SESSION[$nom] = $row[$i];
            //$this->alerta($nombre." - ".$tipo." - ".$flags);
//or strpos($flags, "set")
            //segun tipo de campo, tipo de etiqueta
            if (strpos($flags, "set")  and !$esEnum ){
                 $this->CampoSet(mysql_field_table($result, $i), $nombre, $comment, $row[$i]);
            }
            else if ($tipo == "date" and !$esEnum )
                $this->CreaTextoFecha($nombre, $long, $comment, $row[$i]);
            else if (strpos($nombre, "Color") and !strpos($flags, "enum") and !$esEnum)
                $this->CreaSelectColor($nombre, $comment, $row[$i]);
            else if ($tipo == "int" or $tipo == "real" )
                $this->CreaTextoNumerico($nombre, $long, $comment, $row[$i]);
            else if (!strpos($nombre, "Imagen") and !strpos($flags, "enum") and !$esEnum)
                $this->CreaTexto($nombre, $long, $comment, $row[$i]);
            /*else if (strpos($nombre, "imagen") and !$esEnum and $tipo!="blob")
                $this->CreaImagenRuta($nombre, $comment);*/
            else if (strpos($nombre, "Imagen") and !$esEnum and $tipo=="blob")
                $this->CreaImagen($nombre, $comment);
            else if (strpos($flags, "enum"))
                 $this->CampoEnum(mysql_field_table($result, $i), $nombre, $comment, $row[$i]);
            else if ($esEnum)
            {
               if ($this->select != "")
                  foreach ($this->select as $indice => $contSql)
                  {
                     if ($indice == $nombre and $contSql != "")
                     {
                        if (!isset($Filtro) or $Filtro == "")
                           $row[$i] = "";
                        $this->CreaSelect($nombre, $contSql, $comment, $row[$i]);
                        $CreoSelect = true;
                        break;
                     }
                  }
               if (!$CreoSelect)
               {
                  $this->CreaTexto($nombre, $long, $comment, $row[$i]);
               }
            }
        }
        echo "\n</table>
				\n<input type='submit' value='Cancelar' >
				\n<input type='submit' value='".$_SESSION['sOperacion']."' name='aceptar'>
				\n</form>
				\n</center>";
        mysql_free_result($result);
        exit();
    }
   //paginador de consultas
   /******************************************************/
   /* Funcion paginar
    * actual:          Pagina actual
    * total:           Total de registros
    * por_pagina:      Registros por pagina
    * enlace:          Texto del enlace
    * Devuelve un texto que representa la paginacion
    */
   function paginar($actual, $total, $por_pagina, $enlace) {
     $_SESSION['pagActual']=$actual;
     $total_paginas = ceil($total/$por_pagina);
     $anterior = $actual - 1;
     $posterior = $actual + 1;
     if ($actual>1)
       $texto .= "<a href=\"$enlace$anterior\">&laquo;</a> ";
     else
       $texto .= "<b>&laquo;</b> ";
     for ($i=1; $i<$actual; $i++)
       $texto .= "<a href=\"$enlace$i\">$i</a> ";
     $texto .= "<b>$actual</b> ";
     for ($i=$actual+1; $i<=$total_paginas; $i++)
       $texto .= "<a href=\"$enlace$i\">$i</a> ";
     if ($actual<$total_paginas)
       $texto .= "<a href=\"$enlace$posterior\">&raquo;</a>";
     else
       $texto .= "<b>&raquo;</b>";
     
     echo "\n<br><br>".$texto."\n<br><br>";
   }
   
    //cuenta el numero de filas resultantes
    function contarfilas($sql){
	     $corte = strstr($sql,"FROM");
		  $nuevosql = "SELECT COUNT(*) $corte";
		  //$this->alerta($nuevosql);
        $result=$this->query($nuevosql); 
        list($total)=mysql_fetch_row($result);
        return $total;
    }
    //muestra los registros de la tabla
    function visualizar($pag="",$orderby="")
    {
     	for($i=0;$i<2;$i++){
        $consulta = $this->sql;
         //filas obtenidas
         $total = $this->contarfilas($consulta);
         //tama�o del paginador
         if($total<200):
	           $tampag=20;
         elseif ($total<400):
               $tampag=40;
         else:
            	$tampag=60;
         endif;
         $iniciaren=($pag-1) * $tampag;	//Registro actual
         if($iniciaren<0)$iniciaren=0;
         
         $this->paginar($pag, $total, $tampag, "?pag="); 
         
         if ($orderby !=""){
            $consulta = $this->sql." ORDER BY $orderby LIMIT $iniciaren,$tampag";
         }
         else {
            $consulta = $this->sql." LIMIT $iniciaren,$tampag";  
         }
         
        $result = $this->query($consulta);
        //obtener descripcion de la tabla
        $tablades = $this->comentarioTabla($this->nombreTabla($result, 0));
        //si no tiene, poner como descripcion el nombre de la misma
        if ($tablades == "") $tablades = $this->nombreTabla($result, 0);
        
        echo "\n<center><table class='enhancedtablerowhover'>
				\n<caption>".$tablades."</caption>
				\n<thead>
				\n<tr>
				\n<td scope='col' colspan=2></td>";
				
        for ($i = 0; $i < mysql_num_fields($result); $i++)
        {
            $campo=$this->nombreCampo($result, $i);
            //los campos imagen no mostrarlos
            if (!$this->mostrarCampo($campo))
                continue;
             //obtener descripcion del campo   
            $des = str_replace("/*", "", $this->comentario($this->nombreCampo($result, $i),
                $this->nombreTabla($result, $i)));
            //si no tiene, poner como descripcion el nombre del mismo
            if ($des == "" ) $des = $campo;
            echo "\n<th scope='col' ><a href='?order=$campo'>$des</a></th>";
        }
        echo " \n</tr>
				\n</thead>
				\n<tbody>";
        while ($row = mysql_fetch_array($result))
        {
            $filtro = $this->cifrar($row, $result);
            echo "\n<tr>";
            echo "\n<td class='CrearReporte'>
				\n<a href='$_SERVER[PHP_SELF]?operacion=m&$filtro'>
				\n<img src='".$this->PathImages."editar.png'></a></td>";
            echo "\n<td class='CrearReporte' >
	      	\n<a href='$_SERVER[PHP_SELF]?operacion=b&$filtro'>
				\n<img src='".$this->PathImages."eliminar.png'>
				\n</a></td> ";
            for ($i = 0; $i < mysql_num_fields($result); $i++)
            {
               if(strpos($this->nombreCampo($result, $i), "Imagen") and  $tipo = $this->tipoCampo($result, $i)=="blob")							
			   {
			    	$nombreImagen="";
			    	foreach($this->campollave as $claves){
				    	$nombreImagen.=$row[$claves];	
					}
					$nombreImagen.=".jpg";
                 //$nombreImagen=$row[$this->campollave].".jpg";
                 $img = $this->procesarImagen($row[$i],$nombreImagen);
               }
                if (!$this->mostrarCampo($this->nombreCampo($result, $i)))
                    continue;
                if ($img){
                   echo "\n<td><img src = '$nombreImagen' width = '100' heigth = '100'</img></td>";  
                   $img = false;
                 }
                 else
                   echo "\n<td>".$row[$i]."</td>";
            }
            echo "\n</tr>";
        }
        echo "\n</tr></tbody></table></center>";
        $this->paginar($pag, $total, $tampag, "?pag="); 
        }
    }
 
}
?> 
