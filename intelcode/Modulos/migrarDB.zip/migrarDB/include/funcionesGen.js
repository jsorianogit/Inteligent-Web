//onKeyPress="return solonumeros(event);" 
function solonumeros(e)
 {
        	tecla = (document.all)?e.keyCode:e.which;
			patron = /\d/;
			if (tecla==8) return true;
			if (tecla==0) return true;
			if (tecla==9) return true;
			if (tecla==46) return true;
			return patron.test(String.fromCharCode(tecla));	
}
//onKeyPress="return NoComillas(event);"
function NoComillas(e)
{
     		tecla = (document.all)?e.keyCode:e.which;
       	if (tecla==34) return false;
       	if (tecla==39) return false;
       	if (tecla==180) return false;
}

//CamposCompletos
function Enviar(form) {
	for (i = 0; i < form.elements.length; i++) {
		if (form.elements[i].type == "text" && form.elements[i].value != "") { 
			cadena=form.elements[i].value;
			form.elements[i].value=cadena.toUpperCase();//cadena.toLowerCase();
		}
		if (form.elements[i].type == "text" && form.elements[i].value == "") {  
			alert("Por favor complete todos los campos del formulario"); form.elements[i].focus(); 
			return false; 
		}
	}	
form.submit();
}
//Simulador Tab con la tecla enter
function fn(form,field)
{
	var next=0, found=false
	var f=form
	if(event.keyCode!=13) return;
	for(var i=0;i<f.length;i++) {
		if(field.name==f.item(i).name){
			next=i+1;
			found=true
			break;
		}
	}
	while(found){
		if( f.item(next).disabled==false && f.item(next).type!='hidden'){
			f.item(next).focus();
			break;
		}
		else{
			if(next<f.length-1)
				next=next+1;
			else
				break;
		}
	}
}
//Accion cancelar del Formulario
function Cancelar(form,link)
{
	form.reset();
	document.location=link;
}