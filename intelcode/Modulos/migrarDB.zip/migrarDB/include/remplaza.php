<?php
$palabra ="N�me'ro Uno en el Tercer Numero";
$palabra = str_replace("'","",$palabra);
echo $columna = "'$palabra',";
?>