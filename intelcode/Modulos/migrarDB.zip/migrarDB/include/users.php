<?php
//$_SESSION['ssUsuario']="imolina";
//$_SESSION['ssContrasena']="danae";
if(isset($_SESSION['ssUsuario']) and isset($_SESSION['ssContrasena']))
{
	$sql="SELECT sIdUsuario,sPassword FROM usuarios WHERE sIdUsuario='".$_SESSION['ssUsuario']."' AND sPassword='".$_SESSION['ssContrasena']."'";
	$resul=mysql_query($sql,$link);
	if(!$row=mysql_fetch_array($resul))
	{
	 
      	echo "<SCRIPT LANGUAGE=\"javascript\">
	  			alert('Usuario Invalido');
	  			top.document.location.href = \"../../\";
			</SCRIPT>;";
	    exit();
	}
}
else
{
	  
     echo "<SCRIPT LANGUAGE=\"javascript\">
	  			alert('Usuario Invalido');
				top.document.location.href = \"../../\";
			</SCRIPT>;";
	  exit();
}
?>
